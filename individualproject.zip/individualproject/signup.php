<?php
session_start();
$settings=[
	'host'=>'localhost',
	'db'=>'combowebsite',
	'user'=>'root',
	'password'=>''
];

$opt=[
	PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
	PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
	PDO::ATTR_EMULATE_PREPARES => false
];
//connecting to database
$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',
$settings['user'],$settings['password'],$opt);

//executing and processing results
$result=$pdo->query('SELECT * FROM account');
//include('classes.php');
if(isset($_SESSION['user/email']{0})) header('location: members.php');


function signup(){
	if(count($_POST) >0){
		$password=trim($_POST['password']);
		$email=$_POST['email'];
		//if email is valid
		if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			return 'The email you entered is not valid';
		}
		//if password isn't 8 characters
		if(strlen($password) < 8){
			return "The password is not 8 characters.";
		}
		while($record=$result->fetch(){
			//if the email is taken already
			if($_POST['email'] == $record['email']){
				return 'This email is already taken. Please <a href="signin.php">Sign In</a>';
			}//if username is taken
			else if($_POST['username'] == $record['username']){
				return "This username is already taken. Please try another username.";
			}			
		}
		//add user to database
		$pdo->query('INSERT INTO account(username,name,email,password)
					VALUES ("'.$_POST['username'].'","'.$_POST['name'].'",'.$_POST['email'].'","'.$_POST['password'].'")');
		echo 'You have successfully registered your account. Please <a href="signin.php">Sign In</a>'
		return;
	}
}

if(count($_POST)>0){
	$error=signup();
	if(isset($error{0})) echo $error;
		else header('location: signin.php');
}
?>

<form action="signup.php" method="POST">
Username
<input type="text" name="username" required><br>
Name
<input type="text" name="name"><br>
E-Mail
<input type="email" name="email" required><br>
Password
<input type="password" name="password" required minlength="8"><br>
<button type="submit">Create Account</button>
</form>