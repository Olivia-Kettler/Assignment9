<?php
class database{
	//WIP
	private $host='localhost';
	private $db;
	private $user='root';
	private $password='';
	
	public function set_db(){
		$this->$db=$db;
	}
	static function writeEntry($data){
		$opt=[
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false
	];
		$pdo = new PDO('mysql:host='.$host.';dbname='.$db.';charset=utf8mb4',
		$user,$password,$opt);
		$pdo->query('INSERT INTO '.$db.' VALUES('.$data.')');
	}
	static function editEntry($data,$olddata){
		$opt=[
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false
		];
		$pdo = new PDO('mysql:host='.$host.';dbname='.$db.';charset=utf8mb4',
		$user,$password,$opt);
		$pdo->query('UPDATE '.$db.' SET '.$data.' WHERE '.$olddata);
	}
	static function deleteEntry($data){
		$opt=[
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES => false
		];
		$pdo = new PDO('mysql:host='.$host.';dbname='.$db.';charset=utf8mb4',
		$user,$password,$opt);
		$pdo->query('DELETE FROM '.$db.' WHERE '.$data);
	}
}
class files{
	//writing to a file	
static function writeJSON($file,$data,$mode='w'){
		if(!isset($data)) return;
		if($mode=='a'){
			if(file_exists($file)) $array=readJSON($file);
			if(!is_array($array)) $array=[];
			$array[]=$data;
		}else{
			$array=$data;
		}
		$h=fopen($file,'w+'); //w+ creates file if there isn't one of that name
		fwrite($h,json_encode($array));
		fclose($h);
}
//reading a file
static function readJSON($file,$index=null){
		if(!file_exists($file)) return[];
		$h=fopen($file,'r');
		$output=' ';
		while(!feof($h)) $output.=fgets($h);
		fclose($h);
		return json_decode($output,true);
		$output=json_decode($output,true);
		return !isset($index) ? $output : (isset($output[$index]) ? $output[$index] : null);
	
}
//modifying function
static function modifyJSON($file,$data,$index){
		if(file_exists($file)) 
			$input=readJSON($file);
			$input[$index]=array_merge($input[$index],$data);
			writeJSON($file,$input,'w');
			echo '<pre>';
			print_r($input[$index]);
}
//deleting element function
static function deleteJSON($file,$index){
		if(!file_exists($file)) return false;
		if(!isset($index)){
			unlink($file);
			return true;
		}
		$input=readJSON($file);
		unset($input[$index]);
		writeJSON($file,$input,'w');
	}
}
//deals with signing in and signing up
class user{
	private $email;
	private $password;
	
	public function set_email($email){
		$this->email=$email;
	}
	public function set_password($password){
		$this->password=$password;
	}
	public function set_file($files){
		$this->files=$files;
	}
	public function usersignin(){
		//check id email is valid
		if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			return 'The email you entered is not valid';
		}
		$email=strtolower($email);
		$password=trim($password);
		
		//check is password is valid/meets requirements
		if(strlen($password)<8){
			return 'The password must be at least 8 characters';
		}
		//check if email is in database
		$h=fopen('database.csv.php','r');
		while(!feof($h)){
			$line=fgets($h);
			if(strstr($line,$email)){
				//check if password matches
				$line=explode(';',$line);
				if(!password_verify($password,$line[1])) return 'The password entered does not match
				stored password';
			}
		}
		$_SESSION['user/email']=$email;
		fclose($h);
		return 'The email you entered is not associated with any user account. Please
		<a href="signup.php">Sigh Up</a>';
	}
	public function usersignup(){
		//check id email is valid
		if(!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL)){
			return 'The email you entered is not valid';
		}
		$email=strtolower($email);
		$password=trim($password); //gets rid of white space if any in password
		
		//check is password is valid/meets requirements
		if(strlen($password)<8){
			return 'The password must be at least 8 characters';
		}
		//check if email is in use
		if(!file_exists('database.csv.php')){
			$h=fopen('database.csv.php','w+');
			fwrite($h,'<?php die()?>'."\n");
			fclose($h);
		}
		$h=fopen('database.csv.php','r');
		while(!feof($h)){
			$line=fgets($h);
			if(strstr($line,$email)){
				return'The email is already registered.';
			}
		}
		fclose($h);
		
		//encrypt password
		$password=password_hash($password,PASSWORD_DEFAULT);
		//append data to file
		$h=fopen('database.csv.php','a+');
		fwrite($h,implode(';',[$email,$password])."\n");
		fclose($h);
		echo 'You have successfully registered your account.
		Now you can <a href="signin.php">Sign In</a>';
		return;
	}
}
//handling entities in detail.php and index.php
class maindata{
	private $name;
	private $order;
	private $request;
	private $quantity;
	
	public function set_name($name){
		$this->name=$name;
	}
	public function set_order($order){
		$this->order=$order;
	}
	public function set_request($request){
		$this->request=$request;
	}
	public function set_quantity($quantity){
		$this->quantity=$quantity;
	}
	public function get_name(){
		return $this->name;
	}
	public function get_order(){
		return $this->order;
	}
	public function get_request(){
		return $this->request;
	}
	public function get_quantity(){
		return $this->quantity;
	}
}
?>